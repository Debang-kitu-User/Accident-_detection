import React, { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Heading,
  Text,
  useToast,
} from '@chakra-ui/react';

import { useNavigate } from 'react-router-dom';
import { Link as RouterLink } from 'react-router-dom';
import { Link } from '@chakra-ui/react';

function SignupPage({ setUser, setName, next }) {
  const toast = useToast();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSignup = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch('http://localhost:3000/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          password,
          email,
          firstName: fullName,
          image: 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
        }),
      });

      const data = await res.json();

      if (res.ok) {
        const defaultImage = 'https://cdn-icons-png.flaticon.com/512/149/149071.png';

        localStorage.setItem('userImage', defaultImage);
        localStorage.setItem('userName', fullName);
        localStorage.setItem('isLoggedIn', 'true');

        setUser(defaultImage);
        setName(fullName);
        next(true);

        toast({
          title: 'Signup successful.',
          description: 'You are now logged in.',
          status: 'success',
          duration: 3000,
          isClosable: true,
        });

        navigate('/home');
      } else {
        toast({
          title: 'Signup failed.',
          description: data?.message || 'Something went wrong.',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
      }
    } catch (err) {
      console.error('Signup error:', err);
      toast({
        title: 'Error',
        description: 'Unable to sign up. Please check your connection and try again.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Box
      w="100%"
      h="100vh"
      display="flex"
      justifyContent="center"
      alignItems="center"
      bg="black"
      p={4}
    >
      <Box
        p={8}
        w={{ base: "95%", md: "50%" }}
        bg="black"
        color="#ffd100"
        borderRadius="3xl"
        boxShadow="0 0 15px rgba(128, 128, 128, 0.5)"
      >
        <VStack spacing={6}>
          <Heading as="h2" size="lg" color="#ffd100">
            Create Account
          </Heading>

          <form onSubmit={handleSignup} style={{ width: '100%' }}>
            <VStack spacing={4} align="flex-start" w="100%">
              <FormControl isRequired>
                <FormLabel color="#ffd100">Full Name</FormLabel>
                <Input
                  type="text"
                  placeholder="Full Name"
                  focusBorderColor="#ffd100"
                  bgColor="#d6d6d6"
                  color="gray"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel color="#ffd100">Email</FormLabel>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  focusBorderColor="#ffd100"
                  bgColor="#d6d6d6"
                  color="gray"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel color="#ffd100">Username</FormLabel>
                <Input
                  type="text"
                  placeholder="your_username"
                  focusBorderColor="#ffd100"
                  bgColor="#d6d6d6"
                  color="gray"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel color="#ffd100">Password</FormLabel>
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  focusBorderColor="#ffd100"
                  bgColor="#d6d6d6"
                  color="gray"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <Button
                  size="sm"
                  mt={2}
                  onClick={() => setShowPassword(!showPassword)}
                  bg="gray.600"
                  color="white"
                  _hover={{ bg: "gray.700" }}
                >
                  {showPassword ? "Hide" : "Show"} Password
                </Button>
              </FormControl>

              <Button
                type="submit"
                bg="#ffd100"
                color="black"
                width="100%"
                mt={4}
                _hover={{ bg: '#e5be00' }}
                isLoading={isLoading}
                loadingText="Creating account..."
              >
                Sign Up
              </Button>
            </VStack>
          </form>

          <Text fontSize="sm">
            Already have an account?{' '}
            <Link as={RouterLink} to="/" color="#ffd100" fontWeight="bold">
              Log in
            </Link>
          </Text>
        </VStack>
      </Box>
    </Box>
  );
}

export default SignupPage;