import React, { useState, useEffect } from 'react';
import { Flex } from "@chakra-ui/react";
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './loginPage';
import ParkingApp from './Home/home';
import Profile from './profile/profile';
import SidebarRideCards from './rideHistory/ridehis';
import RideAppLayout from './rideconfn/home';
import Dashboard from './accel/acc';
import SignupPage from './SignupPage'; 

function App() {
  const [curr, next] = useState(false);
  const [user, setUser] = useState(null);
  const [name, setName] = useState('');
  
  const [rides, setRides] = useState([
    { id: 1, position: [40.7128, -74.0060], price: 50, driverName: "John Doe", rating: 4.5 },
    { id: 2, position: [34.0522, -118.2437], price: 20, driverName: "Jane Smith", rating: 4.7 },
    { id: 3, position: [51.5074, -0.1278], price: 30, driverName: "Mike Johnson", rating: 4.2 },
    { id: 4, position: [48.8566, 2.3522], price: 80, driverName: "Lucy Brown", rating: 4.9 },
  ]);

useEffect(() => {
  const storedUser = localStorage.getItem('userImage');
  const storedName = localStorage.getItem('userName');
  const isLoggedIn = localStorage.getItem('isLoggedIn');

  if (storedUser && storedName && isLoggedIn === 'true') {
    setUser(storedUser);
    setName(storedName);
    next(true);
  } else {
    localStorage.removeItem('userImage');
    localStorage.removeItem('userName');
    localStorage.removeItem('isLoggedIn');
    next(false);
  }
}, []);


  // Option 1: Always start with login (for development)
  // useEffect(() => {
  //   // Clear any existing login data and start fresh
  //   localStorage.removeItem('userImage');
  //   localStorage.removeItem('userName');
  //   localStorage.removeItem('isLoggedIn');
  //   next(false);
  // }, []);

  // Option 2: Comment out the above and uncomment this for production behavior
  /*
  useEffect(() => {
    const storedUser = localStorage.getItem('userImage');
    const storedName = localStorage.getItem('userName');
    const isLoggedIn = localStorage.getItem('isLoggedIn');

    // Only restore if all required data exists AND isLoggedIn is explicitly 'true'
    if (storedUser && storedName && isLoggedIn === 'true') {
      setUser(storedUser);
      setName(storedName);
      next(true);
    } else {
      // Clear any partial/invalid data
      localStorage.removeItem('userImage');
      localStorage.removeItem('userName');
      localStorage.removeItem('isLoggedIn');
      next(false);
    }
  }, []);
  */

  return (
    <Flex w="100%" h="100%" p={4} bg="black" justifyContent="center" alignItems="center">
      <Routes>
        {/* Public Routes */}
        <Route 
          path="/" 
          element={
            curr ? <Navigate to="/home" /> : 
            <LoginPage curr={curr} next={next} user={user} setUser={setUser} name={name} setName={setName} />
          } 
        />
        <Route 
          path="/login" 
          element={
            curr ? <Navigate to="/home" /> : 
            <LoginPage curr={curr} next={next} user={user} setUser={setUser} name={name} setName={setName} />
          } 
        />
        <Route 
          path="/signup" 
          element={
            curr ? <Navigate to="/home" /> : 
            <SignupPage setUser={setUser} setName={setName} next={next} />
          } 
        />
        
        {/* Protected Routes */}
        <Route 
          path="/home" 
          element={curr ? <ParkingApp image={user} ride={rides} setride={setRides} /> : <Navigate to="/" />} 
        />
        <Route 
          path="/profile" 
          element={curr ? <Profile image={user} /> : <Navigate to="/" />} 
        />
        <Route 
          path="/settings" 
          element={curr ? <SidebarRideCards ride={rides} /> : <Navigate to="/" />} 
        />
        <Route 
          path="/payment" 
          element={curr ? <RideAppLayout city={rides} setcity={setRides} /> : <Navigate to="/" />} 
        />
        <Route 
          path="/acc" 
          element={curr ? <Dashboard /> : <Navigate to="/" />} 
        />
        
        {/* Catch all other routes */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Flex>
  );
}

export default App;